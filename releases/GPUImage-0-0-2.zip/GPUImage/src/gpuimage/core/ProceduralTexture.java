package gpuimage.core;

import processing.core.*;
import processing.opengl.*;
/**
 * ProceduralTexture ...<br>
 * Each available shaders are define in the GPUImageInterface.
 * 
 * @see #GPUImageInterface
 * @author bonjour
 */
public class ProceduralTexture extends GPUImageBaseEffects{
	
}
